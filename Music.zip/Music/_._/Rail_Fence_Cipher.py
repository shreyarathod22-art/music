# Rail Fence Cipher implementation

def rail_fence_encrypt(text, key):
    rail = [['\n' for _ in range(len(text))] for _ in range(key)]
    dir_down = False
    row, col = 0, 0

    for char in text:
        if row == 0 or row == key - 1:
            dir_down = not dir_down
        rail[row][col] = char
        col += 1
        row += 1 if dir_down else -1

    result = []
    for i in range(key):
        for j in range(len(text)):
            if rail[i][j] != '\n':
                result.append(rail[i][j])

    return ''.join(result)


def rail_fence_decrypt(cipher, key):
    rail = [['\n' for _ in range(len(cipher))] for _ in range(key)]
    dir_down = None
    row, col = 0, 0

    # Mark positions to fill
    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        rail[row][col] = '*'
        col += 1
        row += 1 if dir_down else -1

    # Fill chars
    index = 0
    for i in range(key):
        for j in range(len(cipher)):
            if rail[i][j] == '*' and index < len(cipher):
                rail[i][j] = cipher[index]
                index += 1

    # Read plaintext
    result = []
    row, col = 0, 0
    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        if rail[row][col] != '*':
            result.append(rail[row][col])
            col += 1
        row += 1 if dir_down else -1

    return ''.join(result)


# Sample usage and test cases
if __name__ == "__main__":
    sample_messages = [
        "HELLO WORLD",
        "CRYPTOGRAPHY",
        "SARDAR PATEL",
        "COLUMNAR CIPHER",
        "DOUBLE TRANSPOSITION",
        "SECURE MESSAGE"
    ]

    rail_keys = [3, 4, 2, 5, 3, 7]

    for i in range(6):
        plaintext = sample_messages[i]
        key = rail_keys[i]

        encrypted = rail_fence_encrypt(plaintext, key)
        decrypted = rail_fence_decrypt(encrypted, key)

        print(f"Run {i + 1}:")
        print(f"Plaintext: {plaintext}")
        print(f"Key: {key}")
        print(f"Encrypted: {encrypted}")
        print(f"Decrypted: {decrypted}")
        print(f"Decryption Successful: {plaintext == decrypted}")
        print("-" * 50)
