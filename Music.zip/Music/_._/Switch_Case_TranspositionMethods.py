# Exp02-VineetChanne-2022300013-Source.py

# Rail Fence Cipher implementation
def rail_fence_encrypt(text, key):
    rail = [['\n' for _ in range(len(text))] for _ in range(key)]
    dir_down = False
    row, col = 0, 0
    for char in text:
        if row == 0 or row == key - 1:
            dir_down = not dir_down
        rail[row][col] = char
        col += 1
        row += 1 if dir_down else -1
    result = []
    for i in range(key):
        for j in range(len(text)):
            if rail[i][j] != '\n':
                result.append(rail[i][j])
    return ''.join(result)


def rail_fence_decrypt(cipher, key):
    rail = [['\n' for _ in range(len(cipher))] for _ in range(key)]
    dir_down = None
    row, col = 0, 0
    # Mark positions to fill
    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        rail[row][col] = '*'
        col += 1
        row += 1 if dir_down else -1
    # Fill chars
    index = 0
    for i in range(key):
        for j in range(len(cipher)):
            if rail[i][j] == '*' and index < len(cipher):
                rail[i][j] = cipher[index]
                index += 1
    # Read plaintext
    result = []
    row, col = 0, 0
    for i in range(len(cipher)):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        if rail[row][col] != '*':
            result.append(rail[row][col])
            col += 1
        row += 1 if dir_down else -1
    return ''.join(result)


# Columnar Transposition Cipher implementation
def columnar_transposition_encrypt(plaintext, key):
    num_cols = len(key)
    num_rows = (len(plaintext) + num_cols - 1) // num_cols
    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]
    idx = 0
    for r in range(num_rows):
        for c in range(num_cols):
            if idx < len(plaintext):
                matrix[r][c] = plaintext[idx]
            else:
                matrix[r][c] = ''
            idx += 1
    sorted_key = sorted([(char, i) for i, char in enumerate(key)])
    ciphertext = []
    for char, col in sorted_key:
        for r in range(num_rows):
            if matrix[r][col]:
                ciphertext.append(matrix[r][col])
    return ''.join(ciphertext)


def columnar_transposition_decrypt(ciphertext, key):
    num_cols = len(key)
    num_rows = (len(ciphertext) + num_cols - 1) // num_cols
    col_lens = [num_rows] * num_cols
    last_row_count = num_cols * num_rows - len(ciphertext)
    for i in range(last_row_count):
        col_lens[num_cols - 1 - i] -= 1
    sorted_key = sorted([(char, i) for i, char in enumerate(key)])
    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]
    idx = 0
    for char, col in sorted_key:
        for r in range(col_lens[col]):
            matrix[r][col] = ciphertext[idx]
            idx += 1
    plaintext = []
    for r in range(num_rows):
        for c in range(num_cols):
            if matrix[r][c]:
                plaintext.append(matrix[r][c])
    return ''.join(plaintext)


# Double Transposition Cipher implementation
def double_transposition_encrypt(plaintext, key1, key2):
    first = columnar_transposition_encrypt(plaintext, key1)
    second = columnar_transposition_encrypt(first, key2)
    return second


def double_transposition_decrypt(ciphertext, key1, key2):
    first = columnar_transposition_decrypt(ciphertext, key2)
    second = columnar_transposition_decrypt(first, key1)
    return second


# Sample runs for all three ciphers
sample_rail_messages = [
    "HELLO WORLD",
    "CRYPTOGRAPHY",
    "SARDAR PATEL",
    "COLUMNAR CIPHER",
    "DOUBLE TRANSPOSITION",
    "SECURE MESSAGE"
]
rail_keys = [3, 4, 2, 5, 3, 7]

sample_col_texts = [
    "HELLOWORLD",
    "CRYPTOGRAPHY",
    "SARDARPATEL",
    "COLUMNARCIPHER",
    "DOUBLETRANSPOSITION",
    "SECUREMESSAGE"
]
col_keys = ["ZEBRAS", "KEYWORD", "FACULTY", "SECURE", "PASSWORD", "COMPUTER"]

sample_double_texts = sample_col_texts
double_key_pairs = [
    ("CONVENIENCE", "SUBJECT"),
    ("KEYWORD", "COLUMN"),
    ("FACULTY", "SECURE"),
    ("PASSWORD", "COMPUTER"),
    ("ENCRYPTION", "DECRYPT"),
    ("CLASSICAL", "MODERN")
]

# Generate formatted input-output text
filename = "Exp02-VineetChanne-2022300013-Input-Output.txt"
lines = []

for i in range(6):
    # Rail Fence
    pt_rf = sample_rail_messages[i]
    key_rf = rail_keys[i]
    enc_rf = rail_fence_encrypt(pt_rf, key_rf)
    dec_rf = rail_fence_decrypt(enc_rf, key_rf)

    # Columnar Transposition
    pt_col = sample_col_texts[i]
    key_col = col_keys[i]
    enc_col = columnar_transposition_encrypt(pt_col, key_col)
    dec_col = columnar_transposition_decrypt(enc_col, key_col)

    # Double Transposition
    pt_dob = sample_double_texts[i]
    key1, key2 = double_key_pairs[i]
    enc_dob = double_transposition_encrypt(pt_dob, key1, key2)
    dec_dob = double_transposition_decrypt(enc_dob, key1, key2)

    lines.append(f"Run {i + 1}:")
    lines.append(f"Rail Fence Cipher - Plaintext: {pt_rf} | Key: {key_rf}")
    lines.append(f"Encrypted: {enc_rf}")
    lines.append(f"Decrypted: {dec_rf}")
    lines.append("")
    lines.append(f"Columnar Transposition Cipher - Plaintext: {pt_col} | Key: {key_col}")
    lines.append(f"Encrypted: {enc_col}")
    lines.append(f"Decrypted: {dec_col}")
    lines.append("")
    lines.append(f"Double Transposition Cipher - Plaintext: {pt_dob} | Keys: ({key1}, {key2})")
    lines.append(f"Encrypted: {enc_dob}")
    lines.append(f"Decrypted: {dec_dob}")
    lines.append("------------------------------")

with open(filename, 'w') as f:
    f.write('\n'.join(lines))

print(f"Input-Output file generated: {filename}")
