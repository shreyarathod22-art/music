import string
import numpy as np

# Caesar Cipher functions
def caesar_encrypt(text, shift):
    result = []
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            offset = (ord(char) - base + shift) % 26
            result.append(chr(base + offset))
        else:
            result.append(char)
    return ''.join(result)

def caesar_decrypt(cipher, shift):
    return caesar_encrypt(cipher, -shift)

# Playfair Cipher functions
def generate_playfair_matrix(key):
    key = key.lower().replace("j", "i")
    seen = set()
    matrix = []
    for char in key:
        if char in string.ascii_lowercase and char not in seen:
            matrix.append(char)
            seen.add(char)
    for char in string.ascii_lowercase:
        if char != 'j' and char not in seen:
            matrix.append(char)
            seen.add(char)
    return [matrix[i:i + 5] for i in range(0, 25, 5)]

def find_position(matrix, char):
    for i, row in enumerate(matrix):
        for j, c in enumerate(row):
            if c == char:
                return i, j
    return -1, -1

def playfair_prepare_text(text):
    text = text.lower().replace("j", "i").replace(" ", "")
    prepared = []
    i = 0
    while i < len(text):
        a = text[i]
        b = ''
        if i + 1 < len(text):
            b = text[i + 1]
        if a == b:
            prepared.append(a)
            prepared.append('x')
            i += 1
        else:
            prepared.append(a)
            if b:
                prepared.append(b)
            i += 2
    if len(prepared) % 2 != 0:
        prepared.append('x')
    return prepared

def playfair_encrypt(plaintext, key):
    matrix = generate_playfair_matrix(key)
    text = playfair_prepare_text(plaintext)
    ciphertext = []
    for i in range(0, len(text), 2):
        r1, c1 = find_position(matrix, text[i])
        r2, c2 = find_position(matrix, text[i+1])
        if r1 == r2:  # Same row
            ciphertext.append(matrix[r1][(c1 + 1) % 5])
            ciphertext.append(matrix[r2][(c2 + 1) % 5])
        elif c1 == c2:  # Same column
            ciphertext.append(matrix[(r1 + 1) % 5][c1])
            ciphertext.append(matrix[(r2 + 1) % 5][c2])
        else:  # Rectangle
            ciphertext.append(matrix[r1][c2])
            ciphertext.append(matrix[r2][c1])
    return ''.join(ciphertext)

def playfair_decrypt(ciphertext, key):
    matrix = generate_playfair_matrix(key)
    plaintext = []
    for i in range(0, len(ciphertext), 2):
        r1, c1 = find_position(matrix, ciphertext[i])
        r2, c2 = find_position(matrix, ciphertext[i+1])
        if r1 == r2:  # Same row
            plaintext.append(matrix[r1][(c1 - 1) % 5])
            plaintext.append(matrix[r2][(c2 - 1) % 5])
        elif c1 == c2:  # Same column
            plaintext.append(matrix[(r1 - 1) % 5][c1])
            plaintext.append(matrix[(r2 - 1) % 5][c2])
        else:  # Rectangle
            plaintext.append(matrix[r1][c2])
            plaintext.append(matrix[r2][c1])
    return ''.join(plaintext).rstrip('x')

# Hill Cipher functions
def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        t = m
        m = a % m
        a = t
        t = x0
        x0 = x1 - q * x0
        x1 = t
    if x1 < 0:
        x1 += m0
    return x1

def matrix_mod_inv(matrix, modulus):
    det = int(round(np.linalg.det(matrix)))
    det_inv = mod_inverse(det % modulus, modulus)
    if det_inv == 0:
        raise ValueError("Matrix is not invertible modulo {}".format(modulus))
    matrix_modulus_inv = det_inv * np.round(det * np.linalg.inv(matrix)).astype(int) % modulus
    return matrix_modulus_inv.astype(int)

def hill_prepare_text(text, size):
    text = text.lower().replace(' ', '')
    while len(text) % size != 0:
        text += 'x'
    return text

def hill_encrypt(plaintext, key_matrix):
    size = key_matrix.shape[0]
    plaintext = hill_prepare_text(plaintext, size)
    ciphertext = ''
    for i in range(0, len(plaintext), size):
        block = plaintext[i:i+size]
        vec = np.array([ord(c) - ord('a') for c in block])
        enc_vec = key_matrix.dot(vec) % 26
        ciphertext += ''.join(chr(num + ord('a')) for num in enc_vec)
    return ciphertext

def hill_decrypt(ciphertext, key_matrix):
    size = key_matrix.shape[0]
    decrypt_matrix = matrix_mod_inv(key_matrix, 26)
    plaintext = ''
    for i in range(0, len(ciphertext), size):
        block = ciphertext[i:i+size]
        vec = np.array([ord(c) - ord('a') for c in block])
        dec_vec = decrypt_matrix.dot(vec) % 26
        plaintext += ''.join(chr(num + ord('a')) for num in dec_vec)
    return plaintext.rstrip('x')

# Sample run input and keys
caesar_samples = [
    ("HELLO WORLD", 3),
    ("CRYPTOGRAPHY", 5),
    ("SARDAR PATEL", 10),
    ("ENCRYPTION", 1),
    ("DATA SECURITY", 7),
    ("PYTHON PROGRAM", 2),
]

playfair_samples = [
    ("HELLO WORLD", "MONARCHY"),
    ("CRYPTOGRAPHY", "KEYWORD"),
    ("SARDAR PATEL", "FACULTY"),
    ("ENCRYPTION", "SECURE"),
    ("DATA SECURITY", "PASSWORD"),
    ("PYTHON PROGRAM", "COMPUTER"),
]

hill_key = np.array([[3, 3], [2, 5]])
hill_samples = [
    "HELLO",
    "WORLD",
    "SECURE",
    "PYTHON",
    "CRYPTO",
    "DATA",
]

filename = "Exp01-VineetChanne-2022300013-Input-Output.txt"
output_lines = []

for i in range(6):
    pt_c, key_c = caesar_samples[i]
    enc_c = caesar_encrypt(pt_c, key_c)
    dec_c = caesar_decrypt(enc_c, key_c)

    pt_p, key_p = playfair_samples[i]
    enc_p = playfair_encrypt(pt_p, key_p)
    dec_p = playfair_decrypt(enc_p, key_p)

    pt_h = hill_samples[i]
    enc_h = hill_encrypt(pt_h, hill_key)
    dec_h = hill_decrypt(enc_h, hill_key)

    output_lines.append(f"Run {i+1}:")
    output_lines.append(f"Caesar Cipher - Plaintext: {pt_c} | Key: {key_c}")
    output_lines.append(f"Encrypted: {enc_c}")
    output_lines.append(f"Decrypted: {dec_c}")
    output_lines.append("")
    output_lines.append(f"Playfair Cipher - Plaintext: {pt_p} | Key: {key_p}")
    output_lines.append(f"Encrypted: {enc_p}")
    output_lines.append(f"Decrypted: {dec_p}")
    output_lines.append("")
    output_lines.append(f"Hill Cipher - Plaintext: {pt_h} | Key: [[3, 3], [2, 5]]")
    output_lines.append(f"Encrypted: {enc_h}")
    output_lines.append(f"Decrypted: {dec_h}")
    output_lines.append("--------------------------")

with open(filename, "w") as f:
    f.write("\n".join(output_lines))

print(f"Sample input-output saved to: {filename}")
