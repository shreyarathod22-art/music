import secrets
import hashlib

# Generate a random probable prime (using sympy)
from sympy import randprime

def generate_prime(bits):
    """Generate a random prime of given bit length."""
    low = 2 ** (bits - 1)
    high = 2 ** bits - 1
    return randprime(low, high)

def sha256_hash(value):
    """Return SHA-256 hash of big integer."""
    value_bytes = value.to_bytes((value.bit_length() + 7) // 8, byteorder='big')
    return hashlib.sha256(value_bytes).hexdigest()

def xor_encrypt_decrypt(text, key_bytes):
    """XOR-based simple encryption/decryption."""
    text_bytes = text.encode()
    result = bytearray()
    for i in range(len(text_bytes)):
        result.append(text_bytes[i] ^ key_bytes[i % len(key_bytes)])
    return result.decode(errors='ignore')

def main():
    p = g = None
    a = A = b = B = None
    K_A = K_B = None

    while True:
        print("\n--- Diffie-Hellman Key Exchange ---")
        print("1) Select / Generate Public Parameters (p, g)")
        print("2) Generate Keys for Alice and Bob")
        print("3) Compute Shared Secret")
        print("4) Derive Symmetric Key & Encrypt/Decrypt Demo")
        print("5) Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            bits = int(input("Enter bit length for prime p (e.g., 512): "))
            p = generate_prime(bits)
            g = 2  # simple generator

            print("\nPublic Parameters:")
            print(f"p = {p}")
            print(f"g = {g}")

        elif choice == "2":
            if p is None or g is None:
                print("Please generate (p, g) first.")
                continue

            a = secrets.randbelow(p - 2)
            A = pow(g, a, p)

            b = secrets.randbelow(p - 2)
            B = pow(g, b, p)

            print(f"Alice: Public Key (A) = {A}")
            print(f"Bob:   Public Key (B) = {B}")

        elif choice == "3":
            if A is None or B is None:
                print("Generate keys first.")
                continue

            K_A = pow(B, a, p)
            K_B = pow(A, b, p)

            print(f"Alice computes shared secret K_A = {K_A}")
            print(f"Bob computes shared secret K_B = {K_B}")
            print("Shared Secret Match:", K_A == K_B)

        elif choice == "4":
            if K_A is None:
                print("Compute shared secret first.")
                continue

            sym_key_hex = sha256_hash(K_A)
            sym_key_bytes = sym_key_hex.encode()

            print("Derived Symmetric Key (SHA-256):", sym_key_hex)

            message = input("Enter message to encrypt: ")
            ciphertext = xor_encrypt_decrypt(message, sym_key_bytes)
            decrypted = xor_encrypt_decrypt(ciphertext, sym_key_bytes)

            print("Ciphertext:", ciphertext)
            print("Decrypted:", decrypted)

        elif choice == "5":
            print("Exiting...")
            break

        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
