import string

# Playfair Cipher functions

def generate_playfair_matrix(key):
    key = key.lower().replace("j", "i")
    seen = set()
    matrix = []
    for char in key:
        if char in string.ascii_lowercase and char not in seen:
            matrix.append(char)
            seen.add(char)
    for char in string.ascii_lowercase:
        if char != 'j' and char not in seen:
            matrix.append(char)
            seen.add(char)
    return [matrix[i:i + 5] for i in range(0, 25, 5)]

def find_position(matrix, char):
    for i, row in enumerate(matrix):
        for j, c in enumerate(row):
            if c == char:
                return i, j
    return -1, -1

def playfair_prepare_text(text):
    text = text.lower().replace("j", "i").replace(" ", "")
    prepared = []
    i = 0
    while i < len(text):
        a = text[i]
        b = ''
        if i + 1 < len(text):
            b = text[i + 1]
        if a == b:
            prepared.append(a)
            prepared.append('x')
            i += 1
        else:
            prepared.append(a)
            if b:
                prepared.append(b)
            i += 2
    if len(prepared) % 2 != 0:
        prepared.append('x')
    return prepared

def playfair_encrypt(plaintext, key):
    matrix = generate_playfair_matrix(key)
    text = playfair_prepare_text(plaintext)
    ciphertext = []
    for i in range(0, len(text), 2):
        r1, c1 = find_position(matrix, text[i])
        r2, c2 = find_position(matrix, text[i+1])
        if r1 == r2:  # Same row
            ciphertext.append(matrix[r1][(c1 + 1) % 5])
            ciphertext.append(matrix[r2][(c2 + 1) % 5])
        elif c1 == c2:  # Same column
            ciphertext.append(matrix[(r1 + 1) % 5][c1])
            ciphertext.append(matrix[(r2 + 1) % 5][c2])
        else:  # Rectangle
            ciphertext.append(matrix[r1][c2])
            ciphertext.append(matrix[r2][c1])
    return ''.join(ciphertext)

def playfair_decrypt(ciphertext, key):
    matrix = generate_playfair_matrix(key)
    plaintext = []
    for i in range(0, len(ciphertext), 2):
        r1, c1 = find_position(matrix, ciphertext[i])
        r2, c2 = find_position(matrix, ciphertext[i+1])
        if r1 == r2:  # Same row
            plaintext.append(matrix[r1][(c1 - 1) % 5])
            plaintext.append(matrix[r2][(c2 - 1) % 5])
        elif c1 == c2:  # Same column
            plaintext.append(matrix[(r1 - 1) % 5][c1])
            plaintext.append(matrix[(r2 - 1) % 5][c2])
        else:  # Rectangle
            plaintext.append(matrix[r1][c2])
            plaintext.append(matrix[r2][c1])
    return ''.join(plaintext).rstrip('x')

# Sample runs
playfair_samples = [
    ("HELLO WORLD", "MONARCHY"),
    ("CRYPTOGRAPHY", "KEYWORD"),
    ("SARDAR PATEL", "FACULTY"),
    ("ENCRYPTION", "SECURE"),
    ("DATA SECURITY", "PASSWORD"),
    ("PYTHON PROGRAM", "COMPUTER"),
]

print("Playfair Cipher Examples:")
print("=" * 60)
for i, (plaintext, key) in enumerate(playfair_samples, 1):
    encrypted = playfair_encrypt(plaintext, key)
    decrypted = playfair_decrypt(encrypted, key)
    print(f"\nRun {i}:")
    print(f"Plaintext: {plaintext}")
    print(f"Key: {key}")
    print(f"Encrypted: {encrypted}")
    print(f"Decrypted: {decrypted}")
