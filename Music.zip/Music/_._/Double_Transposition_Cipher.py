# Double Transposition Cipher implementation

def columnar_transposition_encrypt(plaintext, key):
    """Helper function for columnar transposition encryption"""
    num_cols = len(key)
    num_rows = (len(plaintext) + num_cols - 1) // num_cols
    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]

    idx = 0
    for r in range(num_rows):
        for c in range(num_cols):
            if idx < len(plaintext):
                matrix[r][c] = plaintext[idx]
            else:
                matrix[r][c] = ''
            idx += 1

    sorted_key = sorted([(char, i) for i, char in enumerate(key)])

    ciphertext = []
    for char, col in sorted_key:
        for r in range(num_rows):
            if matrix[r][col]:
                ciphertext.append(matrix[r][col])

    return ''.join(ciphertext)


def columnar_transposition_decrypt(ciphertext, key):
    """Helper function for columnar transposition decryption"""
    num_cols = len(key)
    num_rows = (len(ciphertext) + num_cols - 1) // num_cols
    col_lens = [num_rows] * num_cols

    last_row_count = num_cols * num_rows - len(ciphertext)
    for i in range(last_row_count):
        col_lens[num_cols - 1 - i] -= 1

    sorted_key = sorted([(char, i) for i, char in enumerate(key)])

    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]
    idx = 0
    for char, col in sorted_key:
        for r in range(col_lens[col]):
            matrix[r][col] = ciphertext[idx]
            idx += 1

    plaintext = []
    for r in range(num_rows):
        for c in range(num_cols):
            if matrix[r][c]:
                plaintext.append(matrix[r][c])

    return ''.join(plaintext)


def double_transposition_encrypt(plaintext, key1, key2):
    """Encrypt plaintext using double transposition (two columnar transpositions)"""
    first = columnar_transposition_encrypt(plaintext, key1)
    second = columnar_transposition_encrypt(first, key2)
    return second


def double_transposition_decrypt(ciphertext, key1, key2):
    """Decrypt ciphertext using double transposition (reverse order of keys)"""
    first = columnar_transposition_decrypt(ciphertext, key2)
    second = columnar_transposition_decrypt(first, key1)
    return second


# Sample usage and test cases
if __name__ == "__main__":
    sample_double_texts = [
        "HELLOWORLD",
        "CRYPTOGRAPHY",
        "SARDARPATEL",
        "COLUMNARCIPHER",
        "DOUBLETRANSPOSITION",
        "SECUREMESSAGE"
    ]

    double_key_pairs = [
        ("CONVENIENCE", "SUBJECT"),
        ("KEYWORD", "COLUMN"),
        ("FACULTY", "SECURE"),
        ("PASSWORD", "COMPUTER"),
        ("ENCRYPTION", "DECRYPT"),
        ("CLASSICAL", "MODERN")
    ]

    for i in range(6):
        plaintext = sample_double_texts[i]
        key1, key2 = double_key_pairs[i]

        encrypted = double_transposition_encrypt(plaintext, key1, key2)
        decrypted = double_transposition_decrypt(encrypted, key1, key2)

        print(f"Run {i + 1}:")
        print(f"Plaintext: {plaintext}")
        print(f"Keys: ({key1}, {key2})")
        print(f"Encrypted: {encrypted}")
        print(f"Decrypted: {decrypted}")
        print(f"Decryption Successful: {plaintext == decrypted}")
        print("-" * 50)
